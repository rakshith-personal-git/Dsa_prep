import com.aspora.tms.TmsConfig;
import com.aspora.tms.TransactionManagementSystem;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionStatus;
import com.aspora.tms.service.AccountService;
import com.aspora.tms.service.TransactionService;
import com.aspora.tms.util.MutableClock;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Demo walk-through of the wallet Transaction Management System.
 * Time is simulated with a {@link MutableClock} so the day-based limits can be shown in a single run.
 * Tests live in /test: {@code com.aspora.tms.TransactionSystemTest}.
 */
public class Main {
    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    public static void main(String[] args) throws Exception {
        // Demo console only: java.util.logging writes to stderr, which IDEs read separately from stdout, so log lines
        // would print out of order. Route both to stdout and use a one-line log format. Both must run before any logging.
        System.setErr(System.out);
        System.setProperty("java.util.logging.SimpleFormatter.format", "          [%4$s] %5$s%n");

        
        MutableClock clock = new MutableClock(ZonedDateTime.of(2026, 1, 1, 10, 0, 0, 0, IST).toInstant(), IST);
        TransactionManagementSystem tms = new TransactionManagementSystem(TmsConfig.defaults(IST), clock);
        AccountService accounts = tms.accountService();
        TransactionService txns = tms.transactionService();

        String alice = accounts.createAccount("Alice", new BigDecimal("150000")).getId();
        String bob = accounts.createAccount("Bob", new BigDecimal("5000")).getId();
        String mallory = accounts.createAccount("Mallory", new BigDecimal("20000")).getId();

        section(clock, "Day 1 - brand-new accounts: max Rs.10,000 outflow in the first 24h");
        show(txns.transfer(alice, bob, new BigDecimal("8000")));
        show(txns.transfer(alice, bob, new BigDecimal("5000")));      // NEW_ACCOUNT_LIMIT_EXCEEDED
        show(txns.deposit(bob, new BigDecimal("2000")));               // cash in
        show(txns.withdraw(bob, new BigDecimal("500")));               // cash out

        clock.advance(Duration.ofDays(1));
        section(clock, "Day 2 - regular limits: Rs.50,000 per txn, Rs.1,00,000 per calendar day");
        show(txns.transfer(alice, bob, new BigDecimal("60000")));     // TRANSACTION_LIMIT_EXCEEDED
        show(txns.transfer(alice, bob, new BigDecimal("50000")));
        show(txns.transfer(alice, bob, new BigDecimal("45000")));
        show(txns.transfer(alice, bob, new BigDecimal("10000")));     // DAILY_LIMIT_EXCEEDED (95,000 used today)

        section(clock, "Day 2 - bad input, insufficient balance, fraud");
        show(txns.transfer(mallory, bob, new BigDecimal("30000")));   // INSUFFICIENT_BALANCE
        show(txns.transfer(alice, alice, new BigDecimal("100")));     // SAME_ACCOUNT_TRANSFER
        show(txns.transfer(alice, "ACC-999", new BigDecimal("100"))); // ACCOUNT_NOT_FOUND
        show(txns.transfer(alice, bob, new BigDecimal("-10")));       // INVALID_AMOUNT
        accounts.blacklist(mallory, "flagged by risk team");
        show(txns.transfer(bob, mallory, new BigDecimal("100")));     // ACCOUNT_BLACKLISTED

        clock.advance(Duration.ofDays(1));
        section(clock, "Day 3 - the calendar-day limit reset at midnight");
        show(txns.transfer(alice, bob, new BigDecimal("10000")));

        section(clock, "Concurrency - 1,000 parallel transfers in both directions (Alice <-> Bob)");
        BigDecimal totalBefore = accounts.getBalance(alice).add(accounts.getBalance(bob));
        List<Future<Transaction>> results = new ArrayList<>();
        try (ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 1000; i++) {
                boolean aliceToBob = i % 2 == 0;
                results.add(pool.submit(() -> aliceToBob
                        ? txns.transfer(alice, bob, BigDecimal.TEN)
                        : txns.transfer(bob, alice, BigDecimal.TEN)));
            }
        }
        long completed = 0;
        for (Future<Transaction> result : results) {
            if (result.get().getStatus() == TransactionStatus.COMPLETED) {
                completed++;
            }
        }
        BigDecimal totalAfter = accounts.getBalance(alice).add(accounts.getBalance(bob));
        System.out.printf("  completed=%d/1000, Alice+Bob before=%s after=%s (money conserved, no deadlock)%n",
                completed, totalBefore, totalAfter);

        section(clock, "Final state");
        for (String id : List.of(alice, bob, mallory)) {
            System.out.println("  " + accounts.getAccount(id));
        }
        System.out.println("  Failed transactions logged: " + tms.failureLog().entries().size());
    }

    private static void section(MutableClock clock, String title) {
        System.out.printf("%n== %s  [%s IST]%n", title, clock.instant().atZone(IST).toLocalDateTime());
    }

    private static void show(Transaction txn) {
        System.out.println("  " + txn);
    }
}
