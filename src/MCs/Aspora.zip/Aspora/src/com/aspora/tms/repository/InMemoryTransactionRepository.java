package com.aspora.tms.repository;

import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Thread-safe in-memory store with a per-account index (the in-memory equivalent of a DB index). */
public final class InMemoryTransactionRepository implements TransactionRepository {
    private final Map<String, Transaction> byId = new ConcurrentHashMap<>();
    private final Map<String, Queue<Transaction>> byAccountId = new ConcurrentHashMap<>();

    @Override
    public Transaction save(Transaction transaction) {
        // Entities are held by reference, so re-saving after a status change is a no-op here
        // (it would be an UPDATE in a DB-backed repository). Index only on first insert.
        if (byId.putIfAbsent(transaction.getId(), transaction) == null) {
            for (String accountId : transaction.involvedAccountIds()) {
                byAccountId.computeIfAbsent(accountId, id -> new ConcurrentLinkedQueue<>()).add(transaction);
            }
        }
        return transaction;
    }

    @Override
    public Optional<Transaction> findById(String transactionId) {
        return transactionId == null ? Optional.empty() : Optional.ofNullable(byId.get(transactionId));
    }

    @Override
    public List<Transaction> findByAccountId(String accountId) {
        return List.copyOf(transactionsOf(accountId));
    }

    @Override
    public BigDecimal sumCompletedDebits(String accountId, Instant fromInclusive) {
        return transactionsOf(accountId).stream()
                .filter(txn -> txn.getStatus() == TransactionStatus.COMPLETED)
                .filter(txn -> txn.getSourceAccountId().filter(accountId::equals).isPresent())
                .filter(txn -> !txn.getCreatedAt().isBefore(fromInclusive))
                .map(Transaction::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Collection<Transaction> transactionsOf(String accountId) {
        Queue<Transaction> transactions = accountId == null ? null : byAccountId.get(accountId);
        return transactions == null ? List.of() : transactions;
    }
}
