package com.aspora.tms.validation;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.TransactionContext;

import java.math.BigDecimal;

/** Bounds on a single transaction's amount, e.g. Rs.1 to Rs.50,000. */
public final class PerTransactionLimitRule implements ValidationRule {
    private final BigDecimal min;
    private final BigDecimal max;

    public PerTransactionLimitRule(BigDecimal min, BigDecimal max) {
        this.min = min;
        this.max = max;
    }

    @Override
    public void validate(TransactionContext context) {
        BigDecimal amount = context.amount();
        if (amount.compareTo(min) < 0 || amount.compareTo(max) > 0) {
            throw new TransactionException(ErrorCode.TRANSACTION_LIMIT_EXCEEDED,
                    "Amount %s is outside the per-transaction limit [%s, %s]".formatted(amount, min, max));
        }
    }
}
