package com.aspora.tms.repository;

import com.aspora.tms.model.Transaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

/** Storage port for transactions (every transaction is kept, including FAILED ones, as an audit trail). */
public interface TransactionRepository {
    Transaction save(Transaction transaction);

    Optional<Transaction> findById(String transactionId);

    /** Transactions where the account is source or destination, oldest first. */
    List<Transaction> findByAccountId(String accountId);

    /**
     * Total of COMPLETED transactions debiting {@code accountId} created at or after {@code fromInclusive}.
     * Backs the velocity limits. In SQL:
     * {@code SUM(amount) WHERE source_account_id = ? AND status = 'COMPLETED' AND created_at >= ?}
     */
    BigDecimal sumCompletedDebits(String accountId, Instant fromInclusive);
}
