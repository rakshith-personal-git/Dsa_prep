package com.aspora.tms.service;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.fraud.BlacklistRegistry;
import com.aspora.tms.model.Account;
import com.aspora.tms.repository.AccountRepository;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.concurrent.atomic.AtomicLong;

/** Public API for wallet accounts: open, look up, and flag/unflag for fraud. */
public final class AccountService {
    private final AccountRepository accountRepository;
    private final BlacklistRegistry blacklist;
    private final Clock clock;
    private final AtomicLong sequence = new AtomicLong();

    public AccountService(AccountRepository accountRepository, BlacklistRegistry blacklist, Clock clock) {
        this.accountRepository = accountRepository;
        this.blacklist = blacklist;
        this.clock = clock;
    }

    public Account createAccount(String ownerName, BigDecimal openingBalance) {
        if (ownerName == null || ownerName.isBlank()) {
            throw new IllegalArgumentException("Owner name is required");
        }
        if (openingBalance == null || openingBalance.signum() < 0 || openingBalance.stripTrailingZeros().scale() > 2) {
            throw new IllegalArgumentException("Opening balance must be >= 0 with at most 2 decimal places");
        }
        Account account = new Account("ACC-" + sequence.incrementAndGet(), ownerName, openingBalance, clock.instant());
        return accountRepository.save(account);
    }

    public Account getAccount(String accountId) {
        return accountRepository.findById(accountId).orElseThrow(
                () -> new TransactionException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found: " + accountId));
    }

    public BigDecimal getBalance(String accountId) {
        return getAccount(accountId).getBalance();
    }

    public void blacklist(String accountId, String reason) {
        getAccount(accountId); // fail fast on unknown ids
        blacklist.add(accountId, reason);
    }

    public void removeFromBlacklist(String accountId) {
        blacklist.remove(accountId);
    }
}
