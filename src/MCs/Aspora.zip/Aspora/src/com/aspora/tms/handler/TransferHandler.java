package com.aspora.tms.handler;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.model.TransactionType;

/** Wallet to wallet: debit the source, credit the destination. */
public final class TransferHandler implements TransactionHandler {

    @Override
    public TransactionType supportedType() {
        return TransactionType.TRANSFER;
    }

    @Override
    public void validateRequest(Transaction transaction) {
        String from = transaction.getSourceAccountId().orElseThrow(
                () -> new TransactionException(ErrorCode.INVALID_REQUEST, "Transfer requires a source account"));
        String to = transaction.getDestinationAccountId().orElseThrow(
                () -> new TransactionException(ErrorCode.INVALID_REQUEST, "Transfer requires a destination account"));
        if (from.equals(to)) {
            throw new TransactionException(ErrorCode.SAME_ACCOUNT_TRANSFER,
                    "Source and destination are the same account: " + from);
        }
    }

    @Override
    public void execute(TransactionContext context) {
        context.sourceAccount().orElseThrow().debit(context.amount());
        context.destinationAccount().orElseThrow().credit(context.amount());
    }
}
