package com.aspora.tms.repository;

import com.aspora.tms.model.Account;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class InMemoryAccountRepository implements AccountRepository {
    private final Map<String, Account> accounts = new ConcurrentHashMap<>();

    @Override
    public Account save(Account account) {
        accounts.put(account.getId(), account);
        return account;
    }

    @Override
    public Optional<Account> findById(String accountId) {
        return accountId == null ? Optional.empty() : Optional.ofNullable(accounts.get(accountId));
    }
}
