package com.aspora.tms.handler;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.model.TransactionType;

/** Cash out: debit the source wallet (the cash side lives outside this system). */
public final class WithdrawalHandler implements TransactionHandler {

    @Override
    public TransactionType supportedType() {
        return TransactionType.WITHDRAWAL;
    }

    @Override
    public void validateRequest(Transaction transaction) {
        if (transaction.getSourceAccountId().isEmpty() || transaction.getDestinationAccountId().isPresent()) {
            throw new TransactionException(ErrorCode.INVALID_REQUEST, "Withdrawal requires exactly one source account");
        }
    }

    @Override
    public void execute(TransactionContext context) {
        context.sourceAccount().orElseThrow().debit(context.amount());
    }
}
