package com.aspora.tms.validation.window;

import java.time.Instant;

/**
 * Strategy for "which past transactions count towards a periodic limit": everything at or after
 * {@link #windowStart}. Swapping the strategy changes the limit's semantics without touching the rule.
 */
@FunctionalInterface
public interface LimitWindowStrategy {
    Instant windowStart(Instant now);
}
