package com.aspora.tms.repository;

import com.aspora.tms.model.Account;

import java.util.Optional;

/** Storage port for accounts: in-memory today, a DB tomorrow, without touching any caller. */
public interface AccountRepository {
    Account save(Account account);

    Optional<Account> findById(String accountId);
}
