package com.aspora.tms.model;

import com.aspora.tms.exception.ErrorCode;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * One money movement. {@code source} is the account debited and {@code destination} the account credited:
 * TRANSFER has both, DEPOSIT only a destination, WITHDRAWAL only a source. Rules and locking only look at
 * these two sides, which is why they work unchanged for every transaction type.
 * <p>
 * Everything is immutable except the status, which can only move along {@link TransactionStatus#canTransitionTo}.
 */

// id, txnId, acccount, txnNo, type,


public final class Transaction {
    private final String id;
    private final TransactionType type;
    private final String sourceAccountId;
    private final String destinationAccountId;
    private final BigDecimal amount;
    private final Instant createdAt;

    private volatile TransactionStatus status = TransactionStatus.PENDING;
    private volatile Instant updatedAt;
    private volatile ErrorCode failureCode;
    private volatile String failureReason;

    public Transaction(String id, TransactionType type, String sourceAccountId, String destinationAccountId,
                       BigDecimal amount, Instant createdAt) {
        this.id = Objects.requireNonNull(id, "id");
        this.type = Objects.requireNonNull(type, "type");
        this.sourceAccountId = sourceAccountId;
        this.destinationAccountId = destinationAccountId;
        this.amount = amount; // not validated here: a bad amount must still produce a FAILED, logged transaction
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt");
        this.updatedAt = createdAt;
    }

    public synchronized void markProcessing(Instant at) {
        moveTo(TransactionStatus.PROCESSING, at);
    }

    public synchronized void markCompleted(Instant at) {
        moveTo(TransactionStatus.COMPLETED, at);
    }

    public synchronized void markFailed(ErrorCode code, String reason, Instant at) {
        requireTransition(TransactionStatus.FAILED);
        this.failureCode = code;
        this.failureReason = reason;
        moveTo(TransactionStatus.FAILED, at);
    }

    private void moveTo(TransactionStatus next, Instant at) {
        requireTransition(next);
        this.updatedAt = at;
        this.status = next; // volatile write last: whoever sees the new status also sees the fields above
    }

    private void requireTransition(TransactionStatus next) {
        if (!status.canTransitionTo(next)) {
            throw new IllegalStateException("Transaction %s cannot move from %s to %s".formatted(id, status, next));
        }
    }

    /** Accounts this transaction touches - the ones the engine loads, locks and validates. */
    public List<String> involvedAccountIds() {
        return Stream.of(sourceAccountId, destinationAccountId).filter(Objects::nonNull).distinct().toList();
    }

    public String getId() { return id; }
    public TransactionType getType() { return type; }
    /** Account debited; empty for deposits. */
    public Optional<String> getSourceAccountId() { return Optional.ofNullable(sourceAccountId); }
    /** Account credited; empty for withdrawals. */
    public Optional<String> getDestinationAccountId() { return Optional.ofNullable(destinationAccountId); }
    public BigDecimal getAmount() { return amount; }
    public Instant getCreatedAt() { return createdAt; }
    public TransactionStatus getStatus() { return status; }
    public Instant getUpdatedAt() { return updatedAt; }
    /** Null unless FAILED. */
    public ErrorCode getFailureCode() { return failureCode; }
    /** Null unless FAILED. */
    public String getFailureReason() { return failureReason; }

    @Override
    public String toString() {
        String route = getSourceAccountId().orElse("CASH") + " -> " + getDestinationAccountId().orElse("CASH");
        String outcome = status == TransactionStatus.FAILED
                ? "FAILED [%s] %s".formatted(failureCode, failureReason)
                : status.name();
        return "%-7s %-10s %-16s Rs.%-9s %s".formatted(id, type, route, amount, outcome);
    }
}
