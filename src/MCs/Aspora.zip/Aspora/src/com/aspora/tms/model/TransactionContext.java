package com.aspora.tms.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;

/**
 * What rules and handlers work with: the transaction, its accounts (locked by the engine for the whole
 * check-and-apply step) and the evaluation time.
 */
public record TransactionContext(Transaction transaction, Map<String, Account> accounts, Instant now) {

    public BigDecimal amount() {
        return transaction.getAmount();
    }

    /** The account being debited, if any (absent for deposits). */
    public Optional<Account> sourceAccount() {
        return transaction.getSourceAccountId().map(accounts::get);
    }

    /** The account being credited, if any (absent for withdrawals). */
    public Optional<Account> destinationAccount() {
        return transaction.getDestinationAccountId().map(accounts::get);
    }
}
