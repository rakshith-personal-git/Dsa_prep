package com.aspora.tms.model;

/**
 * Transaction lifecycle (a small state machine):
 * <pre>
 *   PENDING ----> PROCESSING ----> COMPLETED
 *      |               |
 *      +----> FAILED <-+
 * </pre>
 * PENDING: accepted and recorded. PROCESSING: accounts locked, rules running, money moving.
 * PENDING -> FAILED covers rejections before locking (bad input, unknown account, lock timeout).
 * COMPLETED and FAILED are terminal.
 */
public enum TransactionStatus {
    PENDING,
    PROCESSING,
    COMPLETED,

    FAILED;

    public boolean canTransitionTo(TransactionStatus next) {
        return switch (this) {
            case PENDING -> next == PROCESSING || next == FAILED;
            case PROCESSING -> next == COMPLETED || next == FAILED;
            case FAILED ->  next == PENDING;
            case COMPLETED -> false;
        };
    }
}
