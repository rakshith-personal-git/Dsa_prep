package com.aspora.tms.event;

import com.aspora.tms.model.Transaction;

/**
 * Observer for transaction outcomes, called once the transaction is COMPLETED/FAILED and its locks are released.
 * Notifications, metrics, fraud analytics... plug in here without touching the engine.
 */
public interface TransactionEventListener {

    default void onCompleted(Transaction transaction) {
    }

    default void onFailed(Transaction transaction) {
    }
}
