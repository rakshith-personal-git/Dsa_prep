package com.aspora.tms.engine;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * One lock per account, so transactions on unrelated accounts run fully in parallel.
 * <ul>
 *   <li>Deadlock-free: multi-account operations always lock in one global order (sorted ids), so
 *       A->B and B->A can never each hold one lock while waiting for the other.</li>
 *   <li>Bounded wait: tryLock with a timeout; a hot or stuck account fails the transaction
 *       (LOCK_TIMEOUT, retryable) instead of blocking the caller forever.</li>
 * </ul>
 */
public final class AccountLockManager {
    private final ConcurrentMap<String, ReentrantLock> locks = new ConcurrentHashMap<>();
    private final Duration timeout;

    public AccountLockManager(Duration timeout) {
        this.timeout = timeout;
    }

    /** Locks every given account; close the returned handle (try-with-resources) to release them. */
    public LockHandle lockAll(Collection<String> accountIds) {
        List<String> ordered = accountIds.stream().distinct().sorted().toList();
        Deque<ReentrantLock> held = new ArrayDeque<>();
        try {
            for (String accountId : ordered) {
                ReentrantLock lock = locks.computeIfAbsent(accountId, id -> new ReentrantLock());
                if (!lock.tryLock(timeout.toMillis(), TimeUnit.MILLISECONDS)) {
                    throw new TransactionException(ErrorCode.LOCK_TIMEOUT,
                            "Timed out after %d ms waiting for the lock on account %s".formatted(timeout.toMillis(), accountId));
                }
                held.push(lock);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            releaseAll(held);
            throw new TransactionException(ErrorCode.SYSTEM_ERROR, "Interrupted while waiting for account locks");
        } catch (RuntimeException e) {
            releaseAll(held);
            throw e;
        }
        return () -> releaseAll(held);
    }

    private static void releaseAll(Deque<ReentrantLock> held) {
        while (!held.isEmpty()) {
            held.pop().unlock(); // reverse order of acquisition
        }
    }

    /** AutoCloseable without a checked exception, so it reads cleanly in try-with-resources. */
    @FunctionalInterface
    public interface LockHandle extends AutoCloseable {
        @Override
        void close();
    }
}
