package com.aspora.tms.validation;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.fraud.BlacklistRegistry;
import com.aspora.tms.model.TransactionContext;

import java.util.Optional;

/** Fraud check: money may neither leave nor enter a blacklisted account. */
public final class BlacklistRule implements ValidationRule {
    private final BlacklistRegistry blacklist;

    public BlacklistRule(BlacklistRegistry blacklist) {
        this.blacklist = blacklist;
    }

    @Override
    public void validate(TransactionContext context) {
        for (String accountId : context.transaction().involvedAccountIds()) {
            Optional<String> reason = blacklist.reasonFor(accountId);
            if (reason.isPresent()) {
                throw new TransactionException(ErrorCode.ACCOUNT_BLACKLISTED,
                        "Account %s is blacklisted: %s".formatted(accountId, reason.get()));
            }
        }
    }
}
