package com.aspora.tms.event;

import com.aspora.tms.model.Transaction;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Logger;

/**
 * Error logging: every failed transaction is logged with full context (ids, accounts, amount, error code,
 * reason, timestamps) and also kept in memory so it can be inspected.
 */
public final class FailedTransactionLogger implements TransactionEventListener {
    private static final Logger LOG = Logger.getLogger(FailedTransactionLogger.class.getName());

    private final Queue<String> entries = new ConcurrentLinkedQueue<>();

    @Override
    public void onFailed(Transaction txn) {
        String entry = "txnId=%s type=%s from=%s to=%s amount=%s code=%s retryable=%s reason=\"%s\" createdAt=%s failedAt=%s"
                .formatted(txn.getId(), txn.getType(),
                        txn.getSourceAccountId().orElse("-"), txn.getDestinationAccountId().orElse("-"),
                        txn.getAmount(), txn.getFailureCode(), txn.getFailureCode().isRetryable(),
                        txn.getFailureReason(), txn.getCreatedAt(), txn.getUpdatedAt());
        entries.add(entry);
        LOG.warning("Transaction failed: " + entry);
    }

    /** Snapshot of everything logged so far (unbounded here; a real system ships these to a log store). */
    public List<String> entries() {
        return List.copyOf(entries);
    }
}
