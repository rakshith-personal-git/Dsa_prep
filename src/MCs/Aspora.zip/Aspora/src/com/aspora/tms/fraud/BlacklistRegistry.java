package com.aspora.tms.fraud;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Accounts flagged by the risk/fraud team, with the reason (in production: a cached lookup into a risk
 * service). Thread-safe; a change applies to the next transaction that touches the account.
 */
public final class BlacklistRegistry {
    private final Map<String, String> reasonByAccountId = new ConcurrentHashMap<>();

    public void add(String accountId, String reason) {
        reasonByAccountId.put(accountId, Objects.requireNonNullElse(reason, "no reason given"));
    }

    public void remove(String accountId) {
        reasonByAccountId.remove(accountId);
    }

    public Optional<String> reasonFor(String accountId) {
        return Optional.ofNullable(reasonByAccountId.get(accountId));
    }
}
