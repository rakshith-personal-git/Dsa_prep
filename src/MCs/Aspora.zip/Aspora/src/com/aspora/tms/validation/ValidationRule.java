package com.aspora.tms.validation;

import com.aspora.tms.model.TransactionContext;

/**
 * One business rule. The engine runs all rules in order (chain; the first violation fails the transaction)
 * while the involved accounts are locked, so a balance/usage check and the debit that follows are atomic.
 * A new rule is a new class registered in {@link com.aspora.tms.TransactionManagementSystem}; nothing else changes.
 */
@FunctionalInterface
public interface ValidationRule {
    /** @throws com.aspora.tms.exception.TransactionException when the transaction violates the rule */
    void validate(TransactionContext context);
}
