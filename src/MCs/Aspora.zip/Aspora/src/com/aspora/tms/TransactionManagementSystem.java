package com.aspora.tms;

import com.aspora.tms.engine.AccountLockManager;
import com.aspora.tms.engine.TransactionProcessor;
import com.aspora.tms.event.FailedTransactionLogger;
import com.aspora.tms.fraud.BlacklistRegistry;
import com.aspora.tms.handler.DepositHandler;
import com.aspora.tms.handler.TransactionHandler;
import com.aspora.tms.handler.TransferHandler;
import com.aspora.tms.handler.WithdrawalHandler;
import com.aspora.tms.repository.AccountRepository;
import com.aspora.tms.repository.InMemoryAccountRepository;
import com.aspora.tms.repository.InMemoryTransactionRepository;
import com.aspora.tms.repository.TransactionRepository;
import com.aspora.tms.service.AccountService;
import com.aspora.tms.service.TransactionService;
import com.aspora.tms.validation.BlacklistRule;
import com.aspora.tms.validation.DailyLimitRule;
import com.aspora.tms.validation.NewAccountLimitRule;
import com.aspora.tms.validation.PerTransactionLimitRule;
import com.aspora.tms.validation.SufficientBalanceRule;
import com.aspora.tms.validation.ValidationRule;

import java.time.Clock;
import java.util.List;

/**
 * Composition root: wires the in-memory system together (manual dependency injection).
 * This is the only class that knows the concrete implementations - add a rule, a transaction type or a
 * listener here, or swap the repositories for DB-backed ones.
 */
public final class TransactionManagementSystem {
    private final AccountService accountService;
    private final TransactionService transactionService;
    private final FailedTransactionLogger failureLog;

    public TransactionManagementSystem(TmsConfig config, Clock clock) {
        AccountRepository accountRepository = new InMemoryAccountRepository();
        TransactionRepository transactionRepository = new InMemoryTransactionRepository();
        BlacklistRegistry blacklist = new BlacklistRegistry();
        this.failureLog = new FailedTransactionLogger();

        // Order only decides which violation is reported first: cheap request-only checks first.
        List<ValidationRule> rules = List.of(
                new PerTransactionLimitRule(config.minPerTransaction(), config.maxPerTransaction()),
                new BlacklistRule(blacklist),
                new SufficientBalanceRule(),
                new NewAccountLimitRule(config.newAccountLimit(), config.newAccountPeriod(), transactionRepository),
                new DailyLimitRule(config.dailyLimit(), config.dailyLimitWindow(), transactionRepository));

        List<TransactionHandler> handlers = List.of(new TransferHandler(), new DepositHandler(), new WithdrawalHandler());

        TransactionProcessor processor = new TransactionProcessor(handlers, rules, accountRepository,
                transactionRepository, new AccountLockManager(config.lockTimeout()), List.of(failureLog), clock);

        this.accountService = new AccountService(accountRepository, blacklist, clock);
        this.transactionService = new TransactionService(processor, transactionRepository);
    }

    public AccountService accountService() {
        return accountService;
    }

    public TransactionService transactionService() {
        return transactionService;
    }

    public FailedTransactionLogger failureLog() {
        return failureLog;
    }
}
