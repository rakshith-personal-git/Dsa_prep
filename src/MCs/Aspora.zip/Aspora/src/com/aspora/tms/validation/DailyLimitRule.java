package com.aspora.tms.validation;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.Account;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.repository.TransactionRepository;
import com.aspora.tms.validation.window.LimitWindowStrategy;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Security limit on total outflow (transfers + withdrawals) per account, e.g. Rs.1,00,000 per day.
 * What "day" means is a pluggable {@link LimitWindowStrategy}: calendar day (resets at local midnight,
 * the default) or a rolling 24h window.
 */
public final class DailyLimitRule implements ValidationRule {
    private final BigDecimal limit;
    private final LimitWindowStrategy window;
    private final TransactionRepository transactionRepository;

    public DailyLimitRule(BigDecimal limit, LimitWindowStrategy window, TransactionRepository transactionRepository) {
        this.limit = limit;
        this.window = window;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public void validate(TransactionContext context) {
        Optional<Account> source = context.sourceAccount();
        if (source.isEmpty()) {
            return; // inflows (deposits) don't consume the outflow limit
        }
        String accountId = source.get().getId();
        BigDecimal used = transactionRepository.sumCompletedDebits(accountId, window.windowStart(context.now()));
        if (used.add(context.amount()).compareTo(limit) > 0) {
            throw new TransactionException(ErrorCode.DAILY_LIMIT_EXCEEDED,
                    "Account %s: daily limit %s, already used %s, requested %s"
                            .formatted(accountId, limit, used, context.amount()));
        }
    }
}
