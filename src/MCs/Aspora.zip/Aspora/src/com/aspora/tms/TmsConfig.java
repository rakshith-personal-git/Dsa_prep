package com.aspora.tms;

import com.aspora.tms.validation.window.CalendarDayWindow;
import com.aspora.tms.validation.window.LimitWindowStrategy;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.ZoneId;

/** Every tunable in one place. Amounts are in INR. */
public record TmsConfig(
        BigDecimal minPerTransaction,
        BigDecimal maxPerTransaction,
        BigDecimal dailyLimit,
        LimitWindowStrategy dailyLimitWindow,
        BigDecimal newAccountLimit,
        Duration newAccountPeriod,
        Duration lockTimeout) {

    /** Rs.1 - Rs.50,000 per transaction; Rs.1,00,000 per calendar day; Rs.10,000 in an account's first 24h. */
    public static TmsConfig defaults(ZoneId zone) {
        return new TmsConfig(
                new BigDecimal("1"),
                new BigDecimal("50000"),
                new BigDecimal("100000"),
                new CalendarDayWindow(zone),
                new BigDecimal("10000"),
                Duration.ofHours(24),
                Duration.ofSeconds(2));
    }

    public TmsConfig withDailyLimitWindow(LimitWindowStrategy window) {
        return new TmsConfig(minPerTransaction, maxPerTransaction, dailyLimit, window,
                newAccountLimit, newAccountPeriod, lockTimeout);
    }
}
