package com.aspora.tms.exception;

/**
 * Rejects an operation with an {@link ErrorCode}. Inside the transaction engine (rules, handlers, locking)
 * it is caught and turned into a FAILED status, so callers of a money movement never see it thrown.
 */
public class TransactionException extends RuntimeException {
    private final ErrorCode errorCode;

    public TransactionException(ErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }
}
