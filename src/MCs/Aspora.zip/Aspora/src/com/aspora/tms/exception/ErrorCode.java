package com.aspora.tms.exception;


public enum ErrorCode {
    INVALID_AMOUNT(false),
    INVALID_REQUEST(false),
    SAME_ACCOUNT_TRANSFER(false),
    UNSUPPORTED_TRANSACTION_TYPE(false),
    ACCOUNT_NOT_FOUND(false),
    ACCOUNT_BLACKLISTED(false),
    INSUFFICIENT_BALANCE(false),
    TRANSACTION_LIMIT_EXCEEDED(false),
    DAILY_LIMIT_EXCEEDED(false),
    NEW_ACCOUNT_LIMIT_EXCEEDED(false),
    LOCK_TIMEOUT(true),
    SYSTEM_ERROR(true);

    private final boolean retryable;

    ErrorCode(boolean retryable) {
        this.retryable = retryable;
    }

    public boolean isRetryable() {
        return retryable;
    }
}
