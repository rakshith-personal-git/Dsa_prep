package com.aspora.tms.service;

import com.aspora.tms.engine.TransactionProcessor;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionType;
import com.aspora.tms.repository.TransactionRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Public API for moving money. Every call returns the transaction in a terminal state:
 * check {@code getStatus()}, and {@code getFailureCode()/getFailureReason()} when it FAILED.
 */
public final class TransactionService {
    private final TransactionProcessor processor;
    private final TransactionRepository transactionRepository;

    public TransactionService(TransactionProcessor processor, TransactionRepository transactionRepository) {
        this.processor = processor;
        this.transactionRepository = transactionRepository;
    }

    public Transaction transfer(String fromAccountId, String toAccountId, BigDecimal amount) {
        return processor.process(TransactionType.TRANSFER, fromAccountId, toAccountId, amount);
    }

    public Transaction deposit(String accountId, BigDecimal amount) {
        return processor.process(TransactionType.DEPOSIT, null, accountId, amount);
    }

    public Transaction withdraw(String accountId, BigDecimal amount) {
        return processor.process(TransactionType.WITHDRAWAL, accountId, null, amount);
    }

    public Optional<Transaction> getTransaction(String transactionId) {
        return transactionRepository.findById(transactionId);
    }

    public List<Transaction> getHistory(String accountId) {
        return transactionRepository.findByAccountId(accountId);
    }
}
