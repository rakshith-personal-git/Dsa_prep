package com.aspora.tms.validation;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.Account;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.repository.TransactionRepository;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Optional;

/**
 * Fraud guard for fresh (possibly mule) accounts: total outflow during the first {@code period} after
 * account creation is capped, e.g. Rs.10,000 in the first 24 hours. Older accounts are unaffected.
 */
public final class NewAccountLimitRule implements ValidationRule {
    private final BigDecimal limit;
    private final Duration period;
    private final TransactionRepository transactionRepository;

    public NewAccountLimitRule(BigDecimal limit, Duration period, TransactionRepository transactionRepository) {
        this.limit = limit;
        this.period = period;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public void validate(TransactionContext context) {
        Optional<Account> source = context.sourceAccount();
        if (source.isEmpty()) {
            return;
        }
        Account account = source.get();
        boolean isNewAccount = context.now().isBefore(account.getCreatedAt().plus(period));
        if (!isNewAccount) {
            return;
        }
        BigDecimal used = transactionRepository.sumCompletedDebits(account.getId(), account.getCreatedAt());
        if (used.add(context.amount()).compareTo(limit) > 0) {
            throw new TransactionException(ErrorCode.NEW_ACCOUNT_LIMIT_EXCEEDED,
                    "Account %s is less than %dh old: limit %s, already used %s, requested %s"
                            .formatted(account.getId(), period.toHours(), limit, used, context.amount()));
        }
    }
}
