package com.aspora.tms.handler;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.model.TransactionType;

/** Cash in: credit the destination wallet (the cash side lives outside this system). */
public final class DepositHandler implements TransactionHandler {

    @Override
    public TransactionType supportedType() {
        return TransactionType.DEPOSIT;
    }

    @Override
    public void validateRequest(Transaction transaction) {
        if (transaction.getDestinationAccountId().isEmpty() || transaction.getSourceAccountId().isPresent()) {
            throw new TransactionException(ErrorCode.INVALID_REQUEST, "Deposit requires exactly one destination account");
        }
    }

    @Override
    public void execute(TransactionContext context) {
        context.destinationAccount().orElseThrow().credit(context.amount());
    }
}
