package com.aspora.tms.validation;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.model.TransactionContext;

/** The debited account must hold at least the amount (no overdraft). Applies to transfers and withdrawals. */
public final class SufficientBalanceRule implements ValidationRule {

    @Override
    public void validate(TransactionContext context) {
        context.sourceAccount().ifPresent(source -> {
            if (source.getBalance().compareTo(context.amount()) < 0) {
                throw new TransactionException(ErrorCode.INSUFFICIENT_BALANCE,
                        "Account %s has balance %s, requested %s"
                                .formatted(source.getId(), source.getBalance(), context.amount()));
            }
        });
    }
}
