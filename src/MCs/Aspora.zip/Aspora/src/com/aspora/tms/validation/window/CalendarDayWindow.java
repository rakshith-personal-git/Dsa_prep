package com.aspora.tms.validation.window;

import java.time.Instant;
import java.time.ZoneId;

/** The limit is per calendar day in the given zone: usage resets at local midnight (end of day). */
public final class CalendarDayWindow implements LimitWindowStrategy {
    private final ZoneId zone;

    public CalendarDayWindow(ZoneId zone) {
        this.zone = zone;
    }

    @Override
    public Instant windowStart(Instant now) {
        return now.atZone(zone).toLocalDate().atStartOfDay(zone).toInstant();
    }
}
