package com.aspora.tms.engine;

import com.aspora.tms.event.TransactionEventListener;
import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.exception.TransactionException;
import com.aspora.tms.handler.TransactionHandler;
import com.aspora.tms.model.Account;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.model.TransactionStatus;
import com.aspora.tms.model.TransactionType;
import com.aspora.tms.repository.AccountRepository;
import com.aspora.tms.repository.TransactionRepository;
import com.aspora.tms.validation.ValidationRule;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * The single pipeline every transaction type goes through (Template Method: type-specific steps are
 * delegated to a {@link TransactionHandler}, business checks to {@link ValidationRule}s):
 * <pre>
 *   save PENDING -> check amount + request shape -> load accounts -> lock accounts (sorted ids)
 *   -> PROCESSING -> run rules -> handler moves money -> COMPLETED -> unlock -> notify listeners
 *   any rejection or error -> FAILED (error code + reason) -> notify listeners (error log)
 * </pre>
 * Failures are reported as a FAILED transaction, never thrown to the caller.
 */
public final class TransactionProcessor {
    private static final Logger LOG = Logger.getLogger(TransactionProcessor.class.getName());

    private final Map<TransactionType, TransactionHandler> handlers;
    private final List<ValidationRule> rules;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final AccountLockManager lockManager;
    private final List<TransactionEventListener> listeners;
    private final Clock clock;
    private final AtomicLong sequence = new AtomicLong();

    public TransactionProcessor(List<TransactionHandler> handlers,
                                List<ValidationRule> rules,
                                AccountRepository accountRepository,
                                TransactionRepository transactionRepository,
                                AccountLockManager lockManager,
                                List<TransactionEventListener> listeners,
                                Clock clock) {
        // toUnmodifiableMap rejects two handlers for one type - that would be a wiring bug
        this.handlers = handlers.stream()
                .collect(Collectors.toUnmodifiableMap(TransactionHandler::supportedType, Function.identity()));
        this.rules = List.copyOf(rules);
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.lockManager = lockManager;
        this.listeners = List.copyOf(listeners);
        this.clock = clock;
    }

    /** Runs one transaction end to end; the returned transaction is always COMPLETED or FAILED. */
    public Transaction process(TransactionType type, String sourceAccountId, String destinationAccountId,
                               BigDecimal amount) {
        Transaction txn = new Transaction("TXN-" + sequence.incrementAndGet(), type,
                sourceAccountId, destinationAccountId, amount, clock.instant());
        transactionRepository.save(txn); // recorded as PENDING first, so even rejected requests leave a trail

        try {
            TransactionHandler handler = handlerFor(type);
            validateAmount(amount);
            handler.validateRequest(txn);
            Map<String, Account> accounts = loadAccounts(txn);

            try (AccountLockManager.LockHandle ignored = lockManager.lockAll(accounts.keySet())) {
                txn.markProcessing(clock.instant());
                TransactionContext context = new TransactionContext(txn, accounts, clock.instant());
                for (ValidationRule rule : rules) {
                    rule.validate(context);
                }
                handler.execute(context);
                // still inside the lock: the next transaction on these accounts sees this one in its limit usage
                txn.markCompleted(clock.instant());
            }
        } catch (TransactionException e) {
            txn.markFailed(e.getErrorCode(), e.getMessage(), clock.instant());
        } catch (RuntimeException e) {
            txn.markFailed(ErrorCode.SYSTEM_ERROR, "Unexpected error: " + e, clock.instant());
        }

        transactionRepository.save(txn);
        notifyListeners(txn); // outside the lock: listeners may do slow I/O
        return txn;
    }

    private TransactionHandler handlerFor(TransactionType type) {
        TransactionHandler handler = handlers.get(type);
        if (handler == null) {
            throw new TransactionException(ErrorCode.UNSUPPORTED_TRANSACTION_TYPE, "No handler registered for " + type);
        }
        return handler;
    }

    private static void validateAmount(BigDecimal amount) {
        if (amount == null || amount.signum() <= 0) {
            throw new TransactionException(ErrorCode.INVALID_AMOUNT, "Amount must be positive, got " + amount);
        }
        if (amount.stripTrailingZeros().scale() > 2) {
            throw new TransactionException(ErrorCode.INVALID_AMOUNT, "Amount can have at most 2 decimal places, got " + amount);
        }
    }

    /** Resolved before locking, so an unknown id never creates a lock. Accounts are never removed. */
    private Map<String, Account> loadAccounts(Transaction txn) {
        Map<String, Account> accounts = new LinkedHashMap<>();
        for (String accountId : txn.involvedAccountIds()) {
            Account account = accountRepository.findById(accountId).orElseThrow(
                    () -> new TransactionException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found: " + accountId));
            accounts.put(accountId, account);
        }
        return Map.copyOf(accounts);
    }

    private void notifyListeners(Transaction txn) {
        for (TransactionEventListener listener : listeners) {
            try {
                if (txn.getStatus() == TransactionStatus.COMPLETED) {
                    listener.onCompleted(txn);
                } else {
                    listener.onFailed(txn);
                }
            } catch (RuntimeException e) {
                // a broken listener must never affect a transaction that has already been decided
                LOG.log(Level.WARNING, "Listener failed for " + txn.getId(), e);
            }
        }
    }
}
