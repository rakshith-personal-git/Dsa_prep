package com.aspora.tms.validation.window;

import java.time.Duration;
import java.time.Instant;

/** Sliding window: the limit applies to the last {@code length} (e.g. 24h) before every transaction. */
public final class RollingWindow implements LimitWindowStrategy {
    private final Duration length;

    public RollingWindow(Duration length) {
        this.length = length;
    }

    @Override
    public Instant windowStart(Instant now) {
        return now.minus(length);
    }
}
