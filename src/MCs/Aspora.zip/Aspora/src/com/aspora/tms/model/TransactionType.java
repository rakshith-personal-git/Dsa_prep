package com.aspora.tms.model;

/**
 * Supported transaction types. Each type is executed by its own
 * {@link com.aspora.tms.handler.TransactionHandler}; a new type (e.g. REFUND) is a new constant plus a new
 * handler registered in {@link com.aspora.tms.TransactionManagementSystem} - the engine does not change.
 */
public enum TransactionType {
    /** Wallet to wallet: debit source, credit destination. */
    TRANSFER,
    /** Cash in / add money: credit destination; money comes from outside the system. */
    DEPOSIT,
    /** Cash out: debit source; money leaves the system. */
    WITHDRAWAL
}
