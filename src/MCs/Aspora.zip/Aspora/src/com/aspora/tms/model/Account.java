package com.aspora.tms.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;

/**
 * A wallet account (single region, so a single currency: INR).
 * <p>
 * The balance is only changed by the transaction engine while it holds this account's lock
 * (see {@link com.aspora.tms.engine.AccountLockManager}); {@code volatile} lets lock-free readers
 * (balance enquiry) always see the latest committed value.
 */
public final class Account {
    private final String id;
    private final String ownerName;
    private final Instant createdAt;
    private volatile BigDecimal balance;

    public Account(String id, String ownerName, BigDecimal openingBalance, Instant createdAt) {
        this.id = Objects.requireNonNull(id, "id");
        this.ownerName = Objects.requireNonNull(ownerName, "ownerName");
        this.balance = Objects.requireNonNull(openingBalance, "openingBalance");
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt");
    }

    /** Caller must hold this account's lock. */
    public void debit(BigDecimal amount) {
        if (balance.compareTo(amount) < 0) {
            // Rules already check this under the same lock; this only guards the "never negative" invariant.
            throw new IllegalStateException("Debit of " + amount + " would overdraw account " + id);
        }
        balance = balance.subtract(amount);
    }

    /** Caller must hold this account's lock. */
    public void credit(BigDecimal amount) {
        balance = balance.add(amount);
    }

    public String getId() { return id; }
    public String getOwnerName() { return ownerName; }
    public Instant getCreatedAt() { return createdAt; }
    public BigDecimal getBalance() { return balance; }

    @Override
    public String toString() {
        return "%s(%s, balance=%s)".formatted(id, ownerName, balance);
    }
}
