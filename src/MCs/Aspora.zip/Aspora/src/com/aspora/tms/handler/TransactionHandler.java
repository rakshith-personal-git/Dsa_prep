package com.aspora.tms.handler;

import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionContext;
import com.aspora.tms.model.TransactionType;

/**
 * Strategy for one {@link TransactionType}. The engine owns everything common (persisting, locking, rules,
 * status, error logging); a handler only knows what differs per type.
 */
public interface TransactionHandler {

    TransactionType supportedType();

    /** Request-shape checks for this type (which sides must be present). Runs before any lock is taken. */
    void validateRequest(Transaction transaction);

    /**
     * Moves the money. Runs only after every rule passed, with all involved accounts locked,
     * so it must not fail half-way (every check belongs in a rule).
     */
    void execute(TransactionContext context);
}
