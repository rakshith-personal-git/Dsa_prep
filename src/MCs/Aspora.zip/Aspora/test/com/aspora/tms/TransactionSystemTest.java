package com.aspora.tms;

import com.aspora.tms.exception.ErrorCode;
import com.aspora.tms.model.Transaction;
import com.aspora.tms.model.TransactionStatus;
import com.aspora.tms.service.AccountService;
import com.aspora.tms.service.TransactionService;
import com.aspora.tms.util.MutableClock;
import com.aspora.tms.validation.window.RollingWindow;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.IntFunction;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Test suite in plain Java (no JUnit - external libraries are not allowed).
 * Run: {@code java -cp <out> com.aspora.tms.TransactionSystemTest} - exits with code 1 if any test fails.
 */
public final class TransactionSystemTest {
    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");
    private static final Instant JAN_1_10AM = at(2026, 1, 1, 10, 0);

    private static int passed;
    private static final List<String> failures = new ArrayList<>();

    public static void main(String[] args) {
        Logger.getLogger("").setLevel(Level.OFF); // silence the failure log; tests assert on it in memory

        run("transfer moves money and completes", TransactionSystemTest::transferMovesMoney);
        run("insufficient balance fails with no side effects", TransactionSystemTest::insufficientBalance);
        run("per-transaction limit", TransactionSystemTest::perTransactionLimit);
        run("invalid inputs fail gracefully", TransactionSystemTest::invalidInputs);
        run("deposit and withdrawal", TransactionSystemTest::depositAndWithdrawal);
        run("daily limit resets at midnight (calendar day)", TransactionSystemTest::dailyLimitCalendarDay);
        run("daily limit with a rolling 24h window", TransactionSystemTest::dailyLimitRollingWindow);
        run("new-account limit applies only in the first 24h", TransactionSystemTest::newAccountLimit);
        run("blacklisted account can neither send nor receive", TransactionSystemTest::blacklist);
        run("status lifecycle is enforced", TransactionSystemTest::statusLifecycle);
        run("failed transactions are logged with context", TransactionSystemTest::failureLogging);
        run("concurrent debits never overdraw", TransactionSystemTest::concurrentDebitsNeverOverdraw);
        run("concurrent debits never breach the daily limit", TransactionSystemTest::concurrentDailyLimit);
        run("concurrent opposite transfers: no deadlock, money conserved", TransactionSystemTest::concurrentTransfersConserveMoney);

        System.out.printf("%n%d passed, %d failed%n", passed, failures.size());
        failures.forEach(failure -> System.out.println("  FAILED: " + failure));
        if (!failures.isEmpty()) {
            System.exit(1);
        }
    }

    // ------------------------------------------------------------------ functional

    private static void transferMovesMoney() {
        Fixture f = new Fixture();
        String alice = f.account("1000");
        String bob = f.account("500");

        Transaction txn = f.txns.transfer(alice, bob, new BigDecimal("300.50"));

        assertCompleted(txn);
        assertMoney("699.50", f.accounts.getBalance(alice));
        assertMoney("800.50", f.accounts.getBalance(bob));
        assertEquals(txn, f.txns.getTransaction(txn.getId()).orElseThrow(), "stored transaction");
        assertEquals(1, f.txns.getHistory(bob).size(), "bob's history size");
    }

    private static void insufficientBalance() {
        Fixture f = new Fixture();
        String alice = f.account("100");
        String bob = f.account("0");

        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("100.01")), ErrorCode.INSUFFICIENT_BALANCE);

        assertMoney("100", f.accounts.getBalance(alice));
        assertMoney("0", f.accounts.getBalance(bob));
    }

    private static void perTransactionLimit() {
        Fixture f = new Fixture();
        String alice = f.account("200000");
        String bob = f.account("0");
        f.ageAccounts();

        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("50000.01")), ErrorCode.TRANSACTION_LIMIT_EXCEEDED);
        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("0.99")), ErrorCode.TRANSACTION_LIMIT_EXCEEDED);
        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));
    }

    private static void invalidInputs() {
        Fixture f = new Fixture();
        String alice = f.account("1000");
        String bob = f.account("0");

        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("-5")), ErrorCode.INVALID_AMOUNT);
        assertFailed(f.txns.transfer(alice, bob, BigDecimal.ZERO), ErrorCode.INVALID_AMOUNT);
        assertFailed(f.txns.transfer(alice, bob, null), ErrorCode.INVALID_AMOUNT);
        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("10.001")), ErrorCode.INVALID_AMOUNT);
        assertFailed(f.txns.transfer(alice, alice, BigDecimal.TEN), ErrorCode.SAME_ACCOUNT_TRANSFER);
        assertFailed(f.txns.transfer(alice, "ACC-404", BigDecimal.TEN), ErrorCode.ACCOUNT_NOT_FOUND);
        assertFailed(f.txns.transfer(null, bob, BigDecimal.TEN), ErrorCode.INVALID_REQUEST);
        assertFailed(f.txns.deposit(null, BigDecimal.TEN), ErrorCode.INVALID_REQUEST);

        assertMoney("1000", f.accounts.getBalance(alice));
        assertMoney("0", f.accounts.getBalance(bob));
    }

    private static void depositAndWithdrawal() {
        Fixture f = new Fixture();
        String alice = f.account("0");

        assertCompleted(f.txns.deposit(alice, new BigDecimal("5000")));
        assertCompleted(f.txns.withdraw(alice, new BigDecimal("1500")));
        assertFailed(f.txns.withdraw(alice, new BigDecimal("3500.01")), ErrorCode.INSUFFICIENT_BALANCE);

        assertMoney("3500", f.accounts.getBalance(alice));
        assertEquals(3, f.txns.getHistory(alice).size(), "history size");
    }

    private static void dailyLimitCalendarDay() {
        Fixture f = new Fixture();
        String alice = f.account("300000");
        String bob = f.account("0");
        f.ageAccounts(); // Jan 2, 11:00 IST

        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));
        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("40000")));
        assertCompleted(f.txns.withdraw(alice, new BigDecimal("10000"))); // withdrawals count too: 1,00,000 used
        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("1")), ErrorCode.DAILY_LIMIT_EXCEEDED);

        f.clock.setInstant(at(2026, 1, 2, 23, 59));
        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("1")), ErrorCode.DAILY_LIMIT_EXCEEDED);

        f.clock.setInstant(at(2026, 1, 3, 0, 0)); // midnight: a new calendar day
        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));
    }

    private static void dailyLimitRollingWindow() {
        Fixture f = new Fixture(TmsConfig.defaults(IST).withDailyLimitWindow(new RollingWindow(Duration.ofHours(24))));
        String alice = f.account("300000");
        String bob = f.account("0");
        f.ageAccounts(); // Jan 2, 11:00 IST

        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));
        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));

        f.clock.setInstant(at(2026, 1, 3, 0, 30)); // past midnight, but within 24h of the debits
        assertFailed(f.txns.transfer(alice, bob, new BigDecimal("1")), ErrorCode.DAILY_LIMIT_EXCEEDED);

        f.clock.setInstant(at(2026, 1, 3, 11, 1)); // the debits have left the 24h window
        assertCompleted(f.txns.transfer(alice, bob, new BigDecimal("50000")));
    }

    private static void newAccountLimit() {
        Fixture f = new Fixture();
        String fresh = f.account("50000");
        String bob = f.account("0");

        assertCompleted(f.txns.transfer(fresh, bob, new BigDecimal("6000")));
        assertCompleted(f.txns.withdraw(fresh, new BigDecimal("4000"))); // 10,000 used
        assertFailed(f.txns.transfer(fresh, bob, new BigDecimal("1")), ErrorCode.NEW_ACCOUNT_LIMIT_EXCEEDED);
        assertCompleted(f.txns.deposit(fresh, new BigDecimal("5000"))); // inflow is not restricted

        f.clock.advance(Duration.ofHours(24)); // no longer a new account
        assertCompleted(f.txns.transfer(fresh, bob, new BigDecimal("20000")));
    }

    private static void blacklist() {
        Fixture f = new Fixture();
        String alice = f.account("1000");
        String mallory = f.account("1000");
        f.accounts.blacklist(mallory, "chargeback fraud");

        assertFailed(f.txns.transfer(alice, mallory, BigDecimal.TEN), ErrorCode.ACCOUNT_BLACKLISTED);
        assertFailed(f.txns.transfer(mallory, alice, BigDecimal.TEN), ErrorCode.ACCOUNT_BLACKLISTED);
        assertFailed(f.txns.withdraw(mallory, BigDecimal.TEN), ErrorCode.ACCOUNT_BLACKLISTED);
        assertFailed(f.txns.deposit(mallory, BigDecimal.TEN), ErrorCode.ACCOUNT_BLACKLISTED);

        f.accounts.removeFromBlacklist(mallory);
        assertCompleted(f.txns.transfer(alice, mallory, BigDecimal.TEN));
    }

    private static void statusLifecycle() {
        Fixture f = new Fixture();
        String alice = f.account("100");
        String bob = f.account("0");
        Transaction done = f.txns.transfer(alice, bob, BigDecimal.ONE);
        assertCompleted(done);

        expectThrows(IllegalStateException.class,
                () -> done.markFailed(ErrorCode.SYSTEM_ERROR, "late failure", Instant.now()));
        assertEquals(TransactionStatus.COMPLETED, done.getStatus(), "terminal status must not change");

        assertTrue(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.PROCESSING), "PENDING -> PROCESSING");
        assertTrue(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.FAILED), "PENDING -> FAILED");
        assertTrue(!TransactionStatus.PENDING.canTransitionTo(TransactionStatus.COMPLETED), "must pass PROCESSING");
        assertTrue(!TransactionStatus.FAILED.canTransitionTo(TransactionStatus.COMPLETED), "FAILED is terminal");
    }

    private static void failureLogging() {
        Fixture f = new Fixture();
        String alice = f.account("100");
        String bob = f.account("0");

        Transaction failed = f.txns.transfer(alice, bob, new BigDecimal("500"));

        List<String> log = f.tms.failureLog().entries();
        assertEquals(1, log.size(), "log entries");
        for (String expected : List.of(failed.getId(), alice, bob, "500", "INSUFFICIENT_BALANCE", "createdAt=")) {
            assertTrue(log.get(0).contains(expected), "log entry should contain '" + expected + "': " + log.get(0));
        }
    }

    // ------------------------------------------------------------------ concurrency

    private static void concurrentDebitsNeverOverdraw() throws Exception {
        Fixture f = new Fixture();
        String alice = f.account("10000");
        String bob = f.account("0");
        f.ageAccounts();

        List<Transaction> results = runConcurrently(200, i -> f.txns.transfer(alice, bob, new BigDecimal("100")));

        assertEquals(100L, countWithStatus(results, TransactionStatus.COMPLETED), "completed transfers");
        assertAllFailuresAre(results, ErrorCode.INSUFFICIENT_BALANCE);
        assertMoney("0", f.accounts.getBalance(alice));
        assertMoney("10000", f.accounts.getBalance(bob));
    }

    private static void concurrentDailyLimit() throws Exception {
        Fixture f = new Fixture();
        String alice = f.account("500000");
        String bob = f.account("0");
        f.ageAccounts();

        List<Transaction> results = runConcurrently(50, i -> f.txns.transfer(alice, bob, new BigDecimal("10000")));

        assertEquals(10L, countWithStatus(results, TransactionStatus.COMPLETED), "completed transfers");
        assertAllFailuresAre(results, ErrorCode.DAILY_LIMIT_EXCEEDED);
        assertMoney("100000", f.accounts.getBalance(bob));
    }

    private static void concurrentTransfersConserveMoney() throws Exception {
        Fixture f = new Fixture();
        List<String> ids = List.of(f.account("50000"), f.account("50000"), f.account("50000"), f.account("50000"));
        f.ageAccounts();

        // every ordered pair (A->B and B->A) is exercised: the worst case for lock-ordering deadlocks
        List<Transaction> results = runConcurrently(4000, i -> {
            String from = ids.get(i % 4);
            String to = ids.get((i % 4 + 1 + (i / 4) % 3) % 4);
            return f.txns.transfer(from, to, new BigDecimal(1 + i % 20));
        });

        assertEquals(4000L, countWithStatus(results, TransactionStatus.COMPLETED), "completed transfers");
        BigDecimal total = ids.stream().map(f.accounts::getBalance).reduce(BigDecimal.ZERO, BigDecimal::add);
        assertMoney("200000", total);
    }

    // ------------------------------------------------------------------ fixture and helpers

    /** A fresh system on a clock the test controls; it starts at 2026-01-01 10:00 IST. */
    private static final class Fixture {
        final MutableClock clock = new MutableClock(JAN_1_10AM, IST);
        final TransactionManagementSystem tms;
        final AccountService accounts;
        final TransactionService txns;

        Fixture() {
            this(TmsConfig.defaults(IST));
        }

        Fixture(TmsConfig config) {
            tms = new TransactionManagementSystem(config, clock);
            accounts = tms.accountService();
            txns = tms.transactionService();
        }

        String account(String openingBalance) {
            return accounts.createAccount("user", new BigDecimal(openingBalance)).getId();
        }

        /** Moves time past the new-account period so only the regular limits apply (now = Jan 2, 11:00 IST). */
        void ageAccounts() {
            clock.advance(Duration.ofHours(25));
        }
    }

    /** Fires {@code count} tasks from 16 threads released together by a start gate, to maximise contention. */
    private static List<Transaction> runConcurrently(int count, IntFunction<Transaction> task) throws Exception {
        CountDownLatch startGate = new CountDownLatch(1);
        List<Future<Transaction>> futures = new ArrayList<>();
        try (ExecutorService pool = Executors.newFixedThreadPool(16)) {
            for (int i = 0; i < count; i++) {
                int n = i;
                futures.add(pool.submit(() -> {
                    startGate.await();
                    return task.apply(n);
                }));
            }
            startGate.countDown();
        }
        List<Transaction> results = new ArrayList<>();
        for (Future<Transaction> future : futures) {
            results.add(future.get(30, TimeUnit.SECONDS));
        }
        return results;
    }

    private static Instant at(int year, int month, int day, int hour, int minute) {
        return ZonedDateTime.of(year, month, day, hour, minute, 0, 0, IST).toInstant();
    }

    private static long countWithStatus(List<Transaction> txns, TransactionStatus status) {
        return txns.stream().filter(txn -> txn.getStatus() == status).count();
    }

    private static void assertAllFailuresAre(List<Transaction> txns, ErrorCode expected) {
        txns.stream()
                .filter(txn -> txn.getStatus() == TransactionStatus.FAILED)
                .forEach(txn -> assertEquals(expected, txn.getFailureCode(), "failure code of " + txn.getId()));
    }

    private static void assertCompleted(Transaction txn) {
        assertEquals(TransactionStatus.COMPLETED, txn.getStatus(), "status of " + txn);
    }

    private static void assertFailed(Transaction txn, ErrorCode expected) {
        assertEquals(TransactionStatus.FAILED, txn.getStatus(), "status of " + txn);
        assertEquals(expected, txn.getFailureCode(), "failure code of " + txn);
    }

    private static void assertMoney(String expected, BigDecimal actual) {
        if (new BigDecimal(expected).compareTo(actual) != 0) {
            throw new AssertionError("expected amount " + expected + " but was " + actual);
        }
    }

    private static void assertEquals(Object expected, Object actual, String what) {
        if (!Objects.equals(expected, actual)) {
            throw new AssertionError(what + ": expected <" + expected + "> but was <" + actual + ">");
        }
    }

    private static void assertTrue(boolean condition, String what) {
        if (!condition) {
            throw new AssertionError(what);
        }
    }

    private static void expectThrows(Class<? extends Throwable> expected, Runnable action) {
        try {
            action.run();
        } catch (Throwable t) {
            if (expected.isInstance(t)) {
                return;
            }
            throw new AssertionError("expected " + expected.getSimpleName() + " but got " + t);
        }
        throw new AssertionError("expected " + expected.getSimpleName() + " but nothing was thrown");
    }

    @FunctionalInterface
    private interface TestCase {
        void run() throws Exception;
    }

    private static void run(String name, TestCase test) {
        try {
            test.run();
            passed++;
            System.out.println("PASS  " + name);
        } catch (Throwable t) {
            failures.add(name + " -> " + t);
            System.out.println("FAIL  " + name + " -> " + t);
        }
    }
}
