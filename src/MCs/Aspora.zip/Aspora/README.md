# Transaction Management System (wallet) - plain Java 21, in-memory

A Paytm-style wallet system for moving money between accounts in one region (single currency INR, time zone IST).
No frameworks, no external libraries, no build tool.

## Setup and run

JDK 21+. From the project root:

```bash
OUT=$(mktemp -d)
javac --release 21 -d "$OUT" $(find src test -name '*.java')
java -cp "$OUT" Main                                  # demo: 3 simulated days of transactions
java -cp "$OUT" com.aspora.tms.TransactionSystemTest  # 14 tests; exit code 1 on failure
```

In IntelliJ, `src` is the source root and `Main.java` is the demo. Mark `test/` as the *Test Sources Root*, then run `TransactionSystemTest.main`.
JUnit isn't used because external libraries aren't allowed; the test class is a small self-contained runner.

## Requirements and where they live

| Requirement | Implementation |
|---|---|
| Account-to-account transfer | `TransferHandler`, run by `TransactionProcessor` |
| Cash deposit / withdrawal (the "new types" case) | `DepositHandler`, `WithdrawalHandler`. Added without changing the engine |
| Balance sufficiency | `SufficientBalanceRule` |
| Per-transaction limit (Rs.1 to Rs.50,000) | `PerTransactionLimitRule` |
| Daily limit Rs.1,00,000, resets at midnight IST | `DailyLimitRule` + `CalendarDayWindow`. A rolling 24h window is available: `RollingWindow` |
| New accounts: at most Rs.10,000 outflow in the first 24h | `NewAccountLimitRule` |
| Fraud: blacklisted accounts can neither send nor receive | `BlacklistRule` + `BlacklistRegistry` |
| Status lifecycle | `TransactionStatus` state machine: PENDING -> PROCESSING -> COMPLETED / FAILED |
| Thread-safe balances, no race conditions | `AccountLockManager`: one lock per account, taken in sorted order, `tryLock` with a timeout |
| Error logging with context | `FailedTransactionLogger` (an observer on transaction outcomes) |

## Architecture

```
Main / tests
   |
TransactionManagementSystem      composition root: wires everything; TmsConfig holds every limit
   |
service     AccountService, TransactionService                        public API
   |
engine      TransactionProcessor (the pipeline) ---- AccountLockManager
   |             |                      |                       |
handler     TransactionHandler     validation  ValidationRule    event  TransactionEventListener
            Transfer / Deposit /   PerTransactionLimit, Blacklist,      FailedTransactionLogger
            Withdrawal             SufficientBalance, NewAccountLimit,
                                   DailyLimit (+ LimitWindowStrategy)
   |
repository  AccountRepository, TransactionRepository  (interfaces + in-memory implementations)
   |
model       Account, Transaction, TransactionType, TransactionStatus, TransactionContext
```

The key modelling choice: a `Transaction` has an optional **source** (the account debited) and an optional **destination** (the account credited).
A transfer has both, a deposit has only a destination, and a withdrawal has only a source.
Locking and every rule work only from these two sides, so none of them depend on the transaction type.

### Processing pipeline (`TransactionProcessor.process`)

1. Create the transaction and save it as **PENDING**, so even rejected requests leave an audit trail.
2. Stateless checks: a handler exists for the type; the amount is > 0 with at most 2 decimals; the request has the right shape for its type (a transfer needs two distinct accounts, and so on).
3. Load the accounts. An unknown id fails with `ACCOUNT_NOT_FOUND` before any lock is taken.
4. Lock every involved account in sorted-id order, with a timeout. Status becomes **PROCESSING**.
5. Run every `ValidationRule`; the first violation wins. Balance and limit checks see a consistent state because the accounts are locked.
6. The handler moves the money and the status becomes **COMPLETED**, still inside the lock.
7. Unlock and notify the listeners.

Any `TransactionException` ends as **FAILED** with an `ErrorCode` and a reason. Any unexpected exception ends as `SYSTEM_ERROR`.

Callers never get an exception for a business failure. They get back a FAILED transaction carrying a code, a reason and a `retryable` flag.

### Design patterns used
- **Strategy**: `TransactionHandler` (one per type), `ValidationRule` (one per rule), `LimitWindowStrategy` (calendar day vs rolling window).
- **Chain of responsibility** (fail-fast): the ordered list of rules.
- **Template method**: the fixed pipeline in `TransactionProcessor`.
- **State machine**: `TransactionStatus.canTransitionTo`, enforced in `Transaction`.
- **Observer**: `TransactionEventListener`; `FailedTransactionLogger` is one listener.
- **Repository**: storage sits behind interfaces, with in-memory implementations.
- **Composition root / manual DI**: `TransactionManagementSystem`.

### Concurrency
- Each account has its own `ReentrantLock`, so transactions on unrelated accounts run in parallel. There is no global lock.
- Locks are always taken in sorted account-id order, so concurrent A->B and B->A transfers cannot deadlock.
- `tryLock(timeout)` means a thread never waits forever. A timeout fails the transaction with `LOCK_TIMEOUT` (retryable).
- The rules, the debit/credit, and the move to COMPLETED all happen under the same locks, so check-then-act is atomic.
- The tests check this with 16 threads:
  - concurrent debits never overdraw an account;
  - concurrent debits never break the daily limit;
  - 4,000 transfers in both directions finish without deadlock, and the total money is unchanged.
- `balance` and `status` are `volatile` so readers that don't take the lock still see the latest value. Storage uses `ConcurrentHashMap` and `ConcurrentLinkedQueue`.

### Extending
- **New transaction type** (e.g. REFUND): add an enum constant and a `TransactionHandler` implementation, then register the handler in `TransactionManagementSystem`. The engine, rules and locking stay the same.
- **New rule** (e.g. maximum wallet balance for min-KYC users): implement `ValidationRule` and add it to the rule list.
- **Rolling 24h window instead of calendar day**: `TmsConfig.defaults(zone).withDailyLimitWindow(new RollingWindow(Duration.ofHours(24)))`.
- **Database**: implement the two repository interfaces. Replace the in-JVM locks with DB row locks (`SELECT ... FOR UPDATE` in id order) or optimistic versioning.

### Assumptions
- One region means one currency (INR) and one time zone (Asia/Kolkata) defines a "day".
- Money is `BigDecimal` with at most 2 decimals, always compared with `compareTo`.
- Limits apply to outflow (transfers and withdrawals). Deposits are not limited, but a load-limit rule could be added.
- Accounts can be opened with a balance for convenience; it does not count towards any limit.
- Processing is synchronous. Time comes from an injected `Clock`, which the demo and tests simulate.

### Next steps
- An idempotency key on every request, so client retries can never debit twice.
- Pre-aggregated usage counters per (account, day) instead of scanning history; time buckets for the rolling window.
- A double-entry ledger (immutable debit/credit entries plus a system cash account) instead of mutable balances.
- Async processing on a queue partitioned by account id, an outbox for events, and a reversal/refund flow.
